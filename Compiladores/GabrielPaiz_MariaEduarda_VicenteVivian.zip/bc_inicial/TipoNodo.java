public class TipoNodo
{
    public static final int Terminal = 0;
    public static final int NaoTerminal = 1;
}
