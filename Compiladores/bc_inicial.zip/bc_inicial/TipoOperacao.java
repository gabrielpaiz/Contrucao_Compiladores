public enum TipoOperacao
{
    ADD, 
    SUB, 
    UMINUS, 
    MULL, 
    DIV, 
    POW, 
    LESS,
    ATRIB,
    IF,
    IFELSE,	
    WHILE,
    SEQ, 
    NULL
}
