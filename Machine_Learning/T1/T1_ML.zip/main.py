import csv
from numpy import NaN
import pandas as pd
#from knn import knn

# with open("penguins.csv", "r") as csvfile:
#     reader = csv.DictReader(csvfile)
#     for row in reader:
#         print(row)

df = pd.read_csv('penguins.csv')
# print(df.info())


list_test = []
for row_index, row in df.iterrows():
    set = ()
    for data in row:
        if type(data) is float and data is not NaN:
            set = set + (data,)
        

    list_test.append(set)
for a in list_test:
    print(len(a))